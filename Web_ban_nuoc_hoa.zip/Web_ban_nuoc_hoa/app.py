from flask import Flask, render_template, request, redirect, url_for, flash, session
from flask_migrate import Migrate  # Import Flask-Migrate
from models import db, Category, Product, InventoryTransaction, User
from datetime import datetime
from werkzeug.utils import secure_filename
from models import ExportedProduct
from datetime import datetime, timedelta
import os
from werkzeug.security import generate_password_hash, check_password_hash

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///perfume_store.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'  # Đường dẫn đến thư mục lưu trữ hình ảnh
app.secret_key = os.urandom(24).hex()  # Sử dụng mã hex để dễ đọc hơn


migrate = Migrate(app, db)
db.init_app(app)

with app.app_context():
    db.create_all()

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        existing_user = User.query.filter_by(username=username).first()
        if existing_user:
            flash('Tên đăng nhập đã tồn tại, vui lòng chọn tên khác.', 'danger')
            return redirect(url_for('register'))
        
        new_user = User(username=username, password_hash=generate_password_hash(password))
        db.session.add(new_user)
        db.session.commit()
        
        flash('Đăng ký thành công, vui lòng đăng nhập.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        
        user = User.query.filter_by(username=username).first()
        
        if user and check_password_hash(user.password_hash, password):
            session['user_id'] = user.id
            flash('Đăng nhập thành công!', 'success')
            return redirect(url_for('index'))
        else:
            flash('Tên đăng nhập hoặc mật khẩu không đúng.', 'danger')
    
    return render_template('login.html')

# Đăng xuất

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    flash('Đăng xuất thành công.')
    return redirect(url_for('login'))

@app.route('/')
def index():
    products = Product.query.all()
    return render_template('index.html', products=products)

@app.route('/product/<int:product_id>')
def product_detail(product_id):
    product = Product.query.get(product_id)
    if not product:
        flash('Sản phẩm không tồn tại.', 'danger')
        return redirect(url_for('index'))
    return render_template('product_detail.html', product=product)


@app.route('/add_product', methods=['GET', 'POST'])
def add_product():
    if request.method == 'POST':
        name = request.form['name']
        description = request.form['description']
        category_id = request.form['category_id']
        data = request.form
        price = data['price'].replace('.', '').replace(',', '.')  # Handle format changes
        quantity_in_stock = request.form['quantity_in_stock']
        
        # Xử lý tải lên ảnh
        image = request.files['image']
        image_filename = secure_filename(image.filename)
        if image_filename != '':
            image.save(os.path.join(app.config['UPLOAD_FOLDER'], image_filename))
        
        new_product = Product(name=name, description=description,
                              category_id=category_id, price=price,
                              quantity_in_stock=quantity_in_stock,
                              image_filename=image_filename)  # Lưu tên tệp hình ảnh vào cơ sở dữ liệu
        db.session.add(new_product)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add_product.html')

@app.route('/edit_product/<int:product_id>', methods=['GET', 'POST'])
def edit_product(product_id):
    product = Product.query.get(product_id)
    if request.method == 'POST':
        product.name = request.form['name']
        product.description = request.form['description']
        product.category_id = request.form['category_id']
        
        # Chuyển đổi giá sang kiểu float, loại bỏ ký tự không cần thiết
        price_str = request.form['price']
        product.price = float(price_str.replace('.', '').replace(' đ', '').replace(',', '.'))
        
        product.quantity_in_stock = request.form['quantity_in_stock']
        db.session.commit()
        return redirect(url_for('index'))
    
    return render_template('edit_product.html', product=product)

@app.route('/delete_product/<int:product_id>', methods=['POST'])
def delete_product(product_id):
    # Xóa tất cả các bản ghi giao dịch liên quan đến product_id trước
    InventoryTransaction.query.filter_by(product_id=product_id).delete()
    db.session.commit()

    # Sau đó xóa sản phẩm
    product = Product.query.get(product_id)
    db.session.delete(product)
    db.session.commit()

    return redirect(url_for('index'))


@app.route('/transactions', methods=['GET', 'POST'])
def transactions():
    if request.method == 'POST':
        product_id = request.form['product_id']
        transaction_type = request.form['transaction_type']
        quantity = request.form['quantity']
        transaction_date = datetime.now()
        quantity = int(quantity)
        
        new_transaction = InventoryTransaction(product_id=product_id,
                                                transaction_type=transaction_type,
                                                quantity=quantity,
                                                transaction_date=transaction_date)
        db.session.add(new_transaction)
        # Update product quantity in stock and record "xuất kho" to ExportedProduct
        product = Product.query.get(product_id)
        if transaction_type == 'IN':
            product.quantity_in_stock += quantity
        elif transaction_type == 'OUT':
            product.quantity_in_stock -= int(quantity)

            # Create an entry in ExportedProduct for "xuất kho" transactions
            exported_product = ExportedProduct(
                product_id=product_id,
                quantity=quantity,
                export_date=transaction_date
            )
            db.session.add(exported_product)

        
        # Update product quantity in stock
        product = Product.query.get(product_id)
        if transaction_type == 'IN':
            product.quantity_in_stock += int(quantity)
        else:
            product.quantity_in_stock -= int(quantity)
        
        db.session.commit()
        return redirect(url_for('index'))
    
    products = Product.query.all()
    return render_template('transactions.html', products=products)

@app.route('/exported_products')
def exported_products():
    exported_products = ExportedProduct.query.all()
    return render_template('exported_products.html', exported_products=exported_products)

@app.route('/predicted_sales')
def predicted_sales():
    # Lấy danh sách sản phẩm đã xuất và số lượng đã xuất
    results = db.session.query(
        ExportedProduct.product_id,
        db.func.sum(ExportedProduct.quantity).label('total_exported')
    ).group_by(ExportedProduct.product_id).order_by(db.desc('total_exported')).all()
    
    products = []
    for result in results:
        product = Product.query.get(result.product_id)
        products.append({
            'product': product,
            'total_exported': result.total_exported
        })

    return render_template('predicted_sales.html', products=products)

if __name__ == '__main__':
    from flask.cli import with_appcontext
    app.run(debug=True)
